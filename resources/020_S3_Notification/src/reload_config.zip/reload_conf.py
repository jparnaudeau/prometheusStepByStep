import subprocess
import os

def lambda_handler(event, context):
    try:
        subprocess.run(["curl", os.environ['endpoint']])
    except:
        raise